﻿' Enum to specify the field type
Public Enum FieldType
	[ReadOnly]
End Enum

