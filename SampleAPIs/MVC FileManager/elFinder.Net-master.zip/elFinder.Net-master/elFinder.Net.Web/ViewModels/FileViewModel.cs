﻿
namespace elFinder.Net.Web.ViewModels
{
    public class FileViewModel
    {
        public string Folder { get; set; }
        public string SubFolder { get; set; }
    }
}