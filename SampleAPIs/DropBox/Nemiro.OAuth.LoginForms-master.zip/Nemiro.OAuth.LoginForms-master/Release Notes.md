### Nemiro.OAuth.LoginForms Release Notes

This document summarizes the changes in recent releases.

#### v1.4 (December 7, 2015)

* Fixed Dropbox;
* Logout implemented.

#### v1.3 (June 25, 2015)

* Support for .NET 3.5;
* Fixed references to Nemiro.OAuth.

#### v1.2 (June 21, 2015)

* Added lock on re-obtain an access token (fixed problem with Dropbox form);
* Automatic switching WebBrowser to latest version IE.

#### v1.1 (February 11, 2015)

* Added the AccessTokenValue property;
* Added form for CodeProject.

#### v1.0 (January 04, 2015)

* First version released.