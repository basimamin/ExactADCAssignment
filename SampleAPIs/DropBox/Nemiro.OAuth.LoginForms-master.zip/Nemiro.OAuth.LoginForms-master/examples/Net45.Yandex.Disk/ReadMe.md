﻿This is a small example of working with **Yandex.Disk**.
___
Это небольшой пример работы с **Яндекс.Диск**.